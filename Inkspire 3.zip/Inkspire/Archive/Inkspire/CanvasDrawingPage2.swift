import SwiftUI

struct CanvasDrawingPage2: View {
    var player1: String
    var player2: String
    var selectedMinutes: Int
    
    @State private var lines: [Line2] = []
    @State private var currentLine = Line2(points: [])
    @State private var selectedColor: Color = .black
    @State private var lineWidth: CGFloat = 4.0
    @State private var timeRemaining: Int = 0
    @State private var timer: Timer? = nil
    @State private var goToSwapPage = false
    
    @Environment(\.dismiss) var dismiss
    
    // 🎭 Unique prompts assigned once per page load
    @State private var prompt1: String = ""
    @State private var prompt2: String = ""
    
    let player1Prompts = [
        "Make it spooky!", "Add humor!", "Add a dramatic twist!",
        "Make it magical!", "Add suspense!"
    ]
    
    let player2Prompts = [
        "Make it mysterious!", "Add a creative twist!", "Make it dramatic!",
        "Add a funny element!", "Add a colorful surprise!"
    ]
    
    var body: some View {
        NavigationStack {
            ZStack {
                Image("BG")
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea()
                
                VStack(spacing: 20) {
                    
                    // Header
                    VStack(spacing: 6) {
                        Text("\(player1) & \(player2)")
                            .font(.title2.bold())
                            .foregroundColor(.black)
                        
                        Text("Time Remaining: \(formatTime(timeRemaining))")
                            .font(.headline)
                            .foregroundColor(.black.opacity(0.8))
                    }
                    .padding(.top, 40)
                    
                    // Prompts
                    VStack(spacing: 12) {
                        Text("\(player1): \(prompt1)")
                            .font(.subheadline)
                            .foregroundColor(.black)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 30)
                        
                        Text("\(player2): \(prompt2)")
                            .font(.subheadline)
                            .foregroundColor(.black)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 30)
                    }
                    
                    Spacer()
                    
                    // Canvas
                    GeometryReader { geometry in
                        ZStack {
                            Color.white
                                .cornerRadius(20)
                                .shadow(radius: 5)
                            
                            ForEach(lines) { line in
                                Path { path in
                                    guard let first = line.points.first else { return }
                                    path.move(to: first)
                                    for point in line.points.dropFirst() {
                                        path.addLine(to: point)
                                    }
                                }
                                .stroke(line.color, lineWidth: line.lineWidth)
                            }
                            
                            Path { path in
                                guard let first = currentLine.points.first else { return }
                                path.move(to: first)
                                for point in currentLine.points.dropFirst() {
                                    path.addLine(to: point)
                                }
                            }
                            .stroke(currentLine.color, lineWidth: currentLine.lineWidth)
                        }
                        .gesture(
                            DragGesture(minimumDistance: 0)
                                .onChanged { value in
                                    currentLine.points.append(value.location)
                                    currentLine.color = selectedColor
                                    currentLine.lineWidth = lineWidth
                                }
                                .onEnded { _ in
                                    lines.append(currentLine)
                                    currentLine = Line2(points: [])
                                }
                        )
                    }
                    .padding(.horizontal)
                    .frame(height: 400)
                    
                    Spacer()
                    
                    // Controls
                    VStack(spacing: 12) {
                        // Colors
                        HStack(spacing: 16) {
                            ForEach([Color.black, .red, .blue, .green, .orange, .purple, .gray], id: \.self) { color in
                                Circle()
                                    .fill(color)
                                    .frame(width: 30, height: 30)
                                    .overlay(
                                        Circle()
                                            .stroke(Color.white, lineWidth: selectedColor == color ? 3 : 0)
                                    )
                                    .onTapGesture {
                                        selectedColor = color
                                    }
                            }
                        }
                        
                        // Brush Size
                        VStack(spacing: 6) {
                            Text("Brush Size: \(Int(lineWidth))")
                                .foregroundColor(.black)
                            Slider(value: $lineWidth, in: 1...10, step: 1)
                                .tint(.black)
                                .padding(.horizontal, 40)
                        }
                        
                        // Undo
                        Button(action: {
                            if !lines.isEmpty {
                                lines.removeLast()
                            }
                        }) {
                            Label("Undo", systemImage: "arrow.uturn.left")
                                .padding()
                                .frame(width: 130)
                                .background(Color.black.opacity(0.8))
                                .foregroundColor(.white)
                                .cornerRadius(25)
                        }
                        .padding(.top, 10)
                        
                        // Done → Swap Page
                        Button(action: {
                            goToSwapPage = true
                        }) {
                            Text("Done")
                                .frame(width: 180, height: 45)
                                .background(Color.gray.opacity(0.5))
                                .foregroundColor(.black)
                                .cornerRadius(12)
                        }
                        .padding(.top, 10)
                        
                        // NavigationLink
                        
                        NavigationLink(
                            destination: SwapYourDrawingPage2_2(
                                player1Name: player1,
                                player2Name: player2,
                                selectedTime: selectedMinutes
                            ),
                            isActive: $goToSwapPage
                        ) {
                            EmptyView()
                        }
                        .hidden()
                    }
                    .padding(.bottom, 40)
                }
            }
            
            .onAppear {
                // Assign random prompts once
                prompt1 = player1Prompts.randomElement() ?? "Draw creatively!"
                prompt2 = player2Prompts.randomElement() ?? "Draw creatively!"
                
                startTimer()
            }
            .navigationBarBackButtonHidden(false)
        }
    }
    
    // Timer
    func startTimer() {
        timeRemaining = selectedMinutes * 60
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            DispatchQueue.main.async {
                if timeRemaining > 0 {
                    timeRemaining -= 1
                } else {
                    timer?.invalidate()
                }
            }
        }
    }
    
    func formatTime(_ seconds: Int) -> String {
        let min = seconds / 60
        let sec = seconds % 60
        return String(format: "%02d:%02d", min, sec)
    }
}

// Line Model
struct Line2: Identifiable {
    let id = UUID()
    var points: [CGPoint]
    var color: Color = .black
    var lineWidth: CGFloat = 4.0
}

#Preview {
    CanvasDrawingPage2(player1: "Tushar", player2: "Aryan", selectedMinutes: 2)
}
