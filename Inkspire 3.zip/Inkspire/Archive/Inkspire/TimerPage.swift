//
//  TimerPage.swift
//  Inkspire 4
//
//  Created by AFP Student 28 on 12/11/25.
//

//
//  TimerPage.swift
//  Inkspire 4
//
//  Created by AFP Student 28 on 12/11/25.
//

import SwiftUI

struct TimerPage: View {
    let player1: String
    let player2: String
    let selectedMinutes: Int
    
    @State private var timeRemaining: Int = 0
    @State private var currentInkIndex: Int = 0
    @State private var timer: Timer? = nil
    
    @State private var goToSwapPage = false  // ✅ State to trigger navigation
    
    // Fixed prompts for round 1
    let prompt1: String
    let prompt2: String
    
    init(player1: String, player2: String, selectedMinutes: Int) {
        self.player1 = player1
        self.player2 = player2
        self.selectedMinutes = selectedMinutes
        
        // Set fixed prompts based on selectedMinutes
        switch selectedMinutes {
        case 1:
            self.prompt1 = "Draw an insect"
            self.prompt2 = "Draw an office item"
        case 2:
            self.prompt1 = "Draw a superhero"
            self.prompt2 = "Draw a spaceship"
        case 3:
            self.prompt1 = "Draw a mountain"
            self.prompt2 = "Draw a robot"
        case 4:
            self.prompt1 = "Draw a castle"
            self.prompt2 = "Draw a submarine"
        case 5:
            self.prompt1 = "Draw a cloud"
            self.prompt2 = "Draw a pizza"
        default:
            self.prompt1 = "Draw anything"
            self.prompt2 = "Draw anything"
        }
    }
    
    var body: some View {
        NavigationStack {
            
            // ✅ Hidden NavigationLink triggered by timer or skip
            NavigationLink(
                destination: SwapYourDrawingPage(
                    player1Name: player1,
                    player2Name: player2,
                    selectedTime: selectedMinutes
                ),
                isActive: $goToSwapPage
            ) {
                EmptyView()
            }
            .hidden()
            
            ZStack {
                Image("BG")
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea()
                
                VStack(spacing: 30) {
                    Spacer()
                    
                    Image("ink_\(currentInkIndex)")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250)
                    
                    Text(formatTime(timeRemaining))
                        .font(.largeTitle.bold())
                        .foregroundColor(.black)
                    
                    VStack(spacing: 5) {
                        Text(player1)
                            .font(.title.bold())
                            .foregroundColor(.black)
                        Text(prompt1)
                            .font(.title3)
                            .foregroundColor(.black)
                    }
                    
                    VStack(spacing: 5) {
                        Text(player2)
                            .font(.title.bold())
                            .foregroundColor(.black)
                        Text(prompt2)
                            .font(.title3)
                            .foregroundColor(.black)
                    }
                    
                    Spacer()
                }
                
                // ✅ Small Skip button in bottom-right corner
                VStack {
                    Spacer()
                    HStack {
                        Spacer()
                        Button(action: {
                            timer?.invalidate()  // Stop timer
                            goToSwapPage = true  // Navigate to next page
                        }) {
                            Image(systemName: "forward.fill")
                                .font(.title3)
                                .foregroundColor(.white)
                                .padding(10)
                                .background(Color.black.opacity(0.5))
                                .clipShape(Circle())
                                .shadow(radius: 3)
                        }
                        .padding(.trailing, 20)
                        .padding(.bottom, 25)
                    }
                }
            }
            .onAppear {
                startTimer()
            }
            .navigationBarBackButtonHidden(true)
        }
    }
    
    func startTimer() {
        timeRemaining = selectedMinutes * 60
        
        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
            if timeRemaining > 0 {
                timeRemaining -= 1
                let progress = 1 - (Double(timeRemaining) / Double(selectedMinutes * 60))
                currentInkIndex = min(18, Int(progress * 18))
            } else {
                timer?.invalidate()
                goToSwapPage = true  // ✅ Trigger navigation automatically
            }
        }
    }
    
    func formatTime(_ seconds: Int) -> String {
        let min = seconds / 60
        let sec = seconds % 60
        return String(format: "%02d:%02d", min, sec)
    }
}

#Preview {
    TimerPage(player1: "Player One", player2: "Player Two", selectedMinutes: 1)
}
