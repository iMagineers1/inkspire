//
//  SwapYourDrawingPage2 2.swift
//  Inkspire 4
//
//  Created by AFP Student 28 on 12/11/25.
//


import SwiftUI

struct SwapYourDrawingPage2: View {
    let player1Name: String
    let player2Name: String
    let selectedTime: Int
    
    @State private var goToNextCanvas = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                Image("BG")
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea()
                
                VStack(spacing: 50) {
                    
                    Spacer()
                    
                    Image("ink_18")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 400)
                    
                    Text("SWAP YOUR \nDRAWINGS")
                        .font(.custom("Chalkduster", size: 35))
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
                    
                    Spacer()
                    
                    Button(action: {
                        goToNextCanvas = true
                    }) {
                        Text("Continue")
                            .frame(width: 180, height: 50)
                            .background(Color.black.opacity(0.3))
                            .foregroundColor(.white)
                            .cornerRadius(12)
                    }
                    .padding(.bottom, 100)
                    
                    NavigationLink(
                        destination: CanvasDrawingPage2(
                            player1: player1Name,
                            player2: player2Name,
                            selectedMinutes: selectedTime
                        ),
                        isActive: $goToNextCanvas
                    ) {
                        EmptyView()
                    }
                    .hidden()
                }
            }
            .navigationBarBackButtonHidden(true)
        }
    }
}

#Preview {
    SwapYourDrawingPage2(player1Name: "Tushar", player2Name: "Aryan", selectedTime: 2)
}
