import SwiftUI

struct DailyChallengePage: View {
    var body: some View {
        ZStack {
            Image("BG")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()

            
            VStack(spacing: 20) {
                
                Text("DAILY \n CHALLENGE")
                    .font(.custom("Chalkduster", size: 40))
                    .font(.system(size: 30, weight: .black))
                    .foregroundColor(.black)
                    .padding(.top, 80)
                                    
                Image("SQUID1")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 250)
                    .padding(40)
                    
                
                    
                
                Text("In this mode, Inkspire gives you two completely random words.\n \n Your challenge? Combine them into one creative drawing!")
                    .font(.body)
                    .foregroundColor(.black.opacity(0.9))
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 60)
                    
                
                NavigationLink(destination: CombinePromptPage()) {
                    HStack {
                        Image(systemName: "play.fill")
                        Text("Play")
                    }
                    .padding()
                    .frame(width: 160)
                    .background(Color.black.opacity(0.8))
                    .foregroundColor(.white)
                    .cornerRadius(25)
                }
                .padding(.bottom, 70)
            }
        }
    }
}

#Preview {
    DailyChallengePage()
}








