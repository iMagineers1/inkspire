import SwiftUI

struct IntroPageApp: View {
    var body: some View {
        ZStack {
            Image("BG")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()
            
            VStack(spacing: 20) {
                
                Text("Inklink")
                    .font(.custom("Chalkduster", size: 55))
                    .foregroundColor(.black)
                    .padding(.top, 80)
                
                Image("squid")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 250)
                    .padding(40)
                
                Text("Ready to draw right here in the app?\n\nUse your finger to sketch something from the given category. Once done, swap and continue the fun!")
                    .font(.body)
                    .foregroundColor(.black.opacity(0.9))
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 50)
                
                // ✅ Play button to go to the drawing canvas
                NavigationLink(destination: PlayerSetupPage2()) {
                    HStack {
                        Image(systemName: "paintbrush.pointed.fill")
                        Text("Start Drawing")
                    }
                    .padding()
                    .frame(width: 200)
                    .background(Color.black.opacity(0.8))
                    .foregroundColor(.white)
                    .cornerRadius(25)
                }
                .padding(.bottom, 60)
            }
        }
        .navigationBarBackButtonHidden(false)
    }
}

#Preview {
    IntroPageApp()
}

