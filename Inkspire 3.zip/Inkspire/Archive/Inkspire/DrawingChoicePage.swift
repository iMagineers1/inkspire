//
//  DrawingChoicePage.swift
//  Inkspire 4
//
//  Created by AFP Student 28 on 12/11/25.
//

import SwiftUI

struct DrawingChoicePage: View {
    var body: some View {
        ZStack {
            Image("background")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()
                .opacity(0.95)
            
            VStack(spacing: 40) {
                Spacer()
                
                Text("How would you like to draw?")
                    .font(.title.bold())
                    .foregroundColor(.black)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 30)
                
                // ✅ Option 1 – Paper drawing
                NavigationLink(destination: IntroPage()) {
                    HStack(spacing: 16) {
                        Image(systemName: "pencil.and.outline")
                            .font(.largeTitle)
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Draw on Paper")
                                .font(.headline)
                            Text("Use your own paper or notebook.")
                                .font(.subheadline)
                        }
                    }
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.black.opacity(0.6))
                    .cornerRadius(20)
                    .shadow(radius: 4)
                    .padding(.horizontal, 40)
                }
                
                // ✅ Option 2 – App drawing
                NavigationLink(destination: IntroPageApp()) {
                    HStack(spacing: 16) {
                        Image(systemName: "paintbrush.pointed.fill")
                            .font(.largeTitle)
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Draw on App")
                                .font(.headline)
                            Text("Use the built-in drawing tool.")
                                .font(.subheadline)
                        }
                    }
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue.opacity(0.7))
                    .cornerRadius(20)
                    .shadow(radius: 4)
                    .padding(.horizontal, 40)
                }
                
                Spacer()
                
                // Back button
                NavigationLink(destination: ContentView()) {
                    Image(systemName: "arrow.left.circle.fill")
                        .font(.system(size: 36))
                        .foregroundColor(.black .opacity(0.6))
                        .padding(.bottom, 40)
                }
            }
        }
        .navigationBarBackButtonHidden(true)
    }
}

#Preview {
    DrawingChoicePage()
}
