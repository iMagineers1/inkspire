//
//  TimerPage2.swift
//  Inkspire 4
//
//  Created by AFP Student 28 on 12/11/25.
//

import SwiftUI

struct TimerPage2: View {
    let player1: String
    let player2: String
    let selectedMinutes: Int
    
    @State private var timeRemaining: Int = 0
    @State private var currentInkIndex: Int = 0
    @State private var timer: Timer? = nil
    
    // Prompts for swapped drawings
    let prompt1: String
    let prompt2: String
    
    @State private var goToSwapPage2 = false   // ✅ Auto navigation
    
    init(player1: String, player2: String, selectedMinutes: Int) {
        self.player1 = player1
        self.player2 = player2
        self.selectedMinutes = selectedMinutes
        
        // Fixed prompts for swap round
        switch selectedMinutes {
        case 1:
            self.prompt1 = "Make \(player2)’s drawing spooky"
            self.prompt2 = "Make \(player1)’s drawing dramatic"
        case 2:
            self.prompt1 = "Add mysterious shadows to \(player2)’s drawing"
            self.prompt2 = "Add suspense to \(player1)’s drawing"
        case 3:
            self.prompt1 = "Turn \(player2)’s drawing into a haunted scene"
            self.prompt2 = "Make \(player1)’s drawing mysterious"
        case 4:
            self.prompt1 = "Add eerie effects to \(player2)’s drawing"
            self.prompt2 = "Make \(player1)’s drawing more dramatic"
        case 5:
            self.prompt1 = "Make \(player2)’s drawing spooky and dramatic"
            self.prompt2 = "Make \(player1)’s drawing suspenseful and mysterious"
        default:
            self.prompt1 = "Make \(player2)’s drawing spooky"
            self.prompt2 = "Make \(player1)’s drawing dramatic"
        }
    }
    
    var body: some View {
        NavigationStack {
            
            // ✅ Hidden NavigationLink to SwapYourDrawingPage2
            NavigationLink(
                destination: SwapYourDrawingPage2(
                    player1Name: player1,
                    player2Name: player2,
                    selectedTime: selectedMinutes
                ),
                isActive: $goToSwapPage2
            ) {
                EmptyView()
            }
            .hidden()
            
            ZStack {
                Image("BG")
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea()
                
                VStack(spacing: 30) {
                    Spacer()
                    
                    Image("ink_\(currentInkIndex)")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250)
                    
                    Text(formatTime(timeRemaining))
                        .font(.largeTitle.bold())
                        .foregroundColor(.black)
                    
                    // Player 1 prompt
                    VStack(spacing: 5) {
                        Text(player1)
                            .font(.title.bold())
                            .foregroundColor(.black)
                        Text(prompt1)
                            .font(.title3)
                            .foregroundColor(.black)
                    }
                    
                    // Player 2 prompt
                    VStack(spacing: 5) {
                        Text(player2)
                            .font(.title.bold())
                            .foregroundColor(.black)
                        Text(prompt2)
                            .font(.title3)
                            .foregroundColor(.black)
                    }
                    
                    Spacer()
                }
                
                // ✅ Small Skip button in bottom-right corner
                VStack {
                    Spacer()
                    HStack {
                        Spacer()
                        Button(action: {
                            timer?.invalidate()   // Stop the timer
                            goToSwapPage2 = true  // Navigate to next page
                        }) {
                            Image(systemName: "forward.fill")
                                .font(.title3)
                                .foregroundColor(.white)
                                .padding(10)
                                .background(Color.black.opacity(0.5))
                                .clipShape(Circle())
                                .shadow(radius: 3)
                        }
                        .padding(.trailing, 20)
                        .padding(.bottom, 25)
                    }
                }
            }
            .onAppear {
                startTimer()
            }
            .navigationBarBackButtonHidden(true)
        }
    }
    
    // MARK: - Timer
    func startTimer() {
        timeRemaining = selectedMinutes * 60
        
        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
            DispatchQueue.main.async {
                if timeRemaining > 0 {
                    timeRemaining -= 1
                    let progress = 1 - (Double(timeRemaining) / Double(selectedMinutes * 60))
                    currentInkIndex = min(18, Int(progress * 18))
                } else {
                    timer?.invalidate()
                    goToSwapPage2 = true   // ✅ Auto-redirect when timer ends
                }
            }
        }
    }
    
    func formatTime(_ seconds: Int) -> String {
        let min = seconds / 60
        let sec = seconds % 60
        return String(format: "%02d:%02d", min, sec)
    }
}

#Preview {
    TimerPage2(player1: "Alice", player2: "Bob", selectedMinutes: 1)
}

