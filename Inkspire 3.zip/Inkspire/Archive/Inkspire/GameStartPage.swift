//
//  GameStartPage.swift
//  Inkspire
//
//  Created by AFP Student 28 on 11/11/25.
//


//
//  GameStartPage.swift
//  INKSPIRE
//
//  Created by AFP Student 28 on 11/11/25.
//

import SwiftUI

struct GameStartPage: View {
    var player1: String
    var player2: String
    var timer: Int
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            VStack(spacing: 30) {
                
                HStack {
                    NavigationLink(destination: PlayerSetupPage()) {
                        HStack {
                            Image(systemName: "chevron.left")
                            Text("Back")
                        }
                        .foregroundColor(.white)
                        .padding()
                    }
                    Spacer()
                }
                
                Text("Get Ready!")
                    .font(.largeTitle.bold())
                    .foregroundColor(.white)
                
                Text("Player 1: \(player1)\nPlayer 2: \(player2)\nTimer: \(timer) minutes")
                    .foregroundColor(.white.opacity(0.8))
                    .multilineTextAlignment(.center)
                
                Spacer()
            }
        }
    }
}


