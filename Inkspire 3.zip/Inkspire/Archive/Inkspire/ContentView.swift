import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack {
            
            VStack(spacing: 32) {
                
                Image("Logo")
                    .resizable()
                    .scaledToFit()
                    .frame(height: 140)
                    .padding(.top, 32)
                
                VStack(spacing: 28) {
                    
                    // ✅ Updated INKLINK link
                    NavigationLink(destination: DrawingChoicePage()) {
                        GameButton(title: "INKLINK", subtitle: "Draw, swap and laugh!") {
                            Image("squids")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 160, height: 160)
                        }
                    }
                    
                    NavigationLink(destination: DailyChallengePage()) {
                        GameButton(title: "DAILY CHALLENGE", subtitle: "Mix the weird, sketch the wild!") {
                            Image("squid")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 130, height: 130)
                        }
                    }
                }

                Spacer()
            }
            .padding(.horizontal, 20)
            .background(
                Image("background")
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea()
            )
        }
        .navigationBarBackButtonHidden(true)
    }
}

#Preview {
    ContentView()
}
