import SwiftUI

struct IntroPage: View {
    var body: some View {
        ZStack {
            Image("BG")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()

            
            VStack(spacing: 20) {
                
                Text("Inklink")
                    .font(.custom("Chalkduster", size: 55))
                    
                    .font(.system(size: 40, weight: .black))
                    .foregroundColor(.black)
                    .padding(.top, 80)
                
                Image("squids")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 250)
                    .padding(40)
                    
                
                    
                
                Text("Start by drawing something from the given category, then swap drawings with your partner.\n\nInkspire gives a fun twist, and you both transform each other’s art based on the theme.")
                    .font(.body)
                    .foregroundColor(.black.opacity(0.9))
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 50)
                    
                
                NavigationLink(destination: PlayerSetupPage()) {
                    HStack {
                        Image(systemName: "play.fill")
                        Text("Play")
                    }
                    .padding()
                    .frame(width: 160)
                    .background(Color.black.opacity(0.8))
                    .foregroundColor(.white)
                    .cornerRadius(25)
                }
                .padding(.bottom, 60)
            }
        }
    }
}

#Preview {
    IntroPage()
}

