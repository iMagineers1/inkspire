//
//  PlayerSetupPage.swift
//  Inkspire
//
//  Created by AFP Student 28 on 11/11/25.
//


import SwiftUI

struct PlayerSetupPage: View {
    @State private var player1 = ""
    @State private var player2 = ""
    
    @State private var selectedTime: Int = 1
    let times = [1, 2, 3, 4, 5]
    
    var body: some View {
        ZStack {
            Image("BG")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()
            
            VStack(spacing: 30) {
                
                Spacer()
                
                // ✅ Player 1
                VStack(alignment: .leading, spacing: 15) {
                    Text("Player 1")
                        .foregroundColor(.black)
                        .font(.title2.bold())
                    
                    TextField("Your name", text: $player1)
                        .padding(15)
                        .background(Color.gray.opacity(0.5))
                        .cornerRadius(20)
                        .foregroundColor(.black)
                }
                .padding(.horizontal, 50)
                
                // ✅ Player 2
                VStack(alignment: .leading, spacing: 15) {
                    Text("Player 2")
                        .foregroundColor(.black)
                        .font(.title2.bold())
                    
                    TextField("Your name", text: $player2)
                        .padding(15)
                        .background(Color.gray.opacity(0.5))
                        .cornerRadius(20)
                        .foregroundColor(.black)
                }
                .padding(.horizontal, 50)
                
                Spacer()
                
                // ✅ Timer
                VStack(spacing: 10) {
                    Text("Set a Timer")
                        .foregroundColor(.black)
                        .font(.system(size: 20, weight: .black))
                        .padding(15)
                    
                    HStack(spacing: 12) {
                        ForEach(times, id: \.self) { time in
                            Button(action: {
                                selectedTime = time
                            }) {
                                Text("\(time) min")
                                    .padding(.vertical, 10)
                                    .padding(.horizontal, 12)
                                    .background(selectedTime == time ?
                                                Color.black.opacity(0.4) :
                                                Color.black.opacity(0.2))
                                    .cornerRadius(8)
                                    .foregroundColor(.white)
                            }
                        }
                    }
                }
                
                Spacer()
                
                // ✅ NEXT BUTTON — DIRECT TO TIMER PAGE
                NavigationLink(
                    destination: TimerPage(
                        player1: player1,
                        player2: player2,
                        selectedMinutes: selectedTime
                    )
                ) {
                    Text("Next")
                        .frame(width: 160, height: 45)
                        .background(Color.gray.opacity(0.5))
                        .foregroundColor(.black)
                        .cornerRadius(12)
                }
                .padding(.bottom, 100)
            }
            .navigationBarBackButtonHidden(false)
        }
    }
}

#Preview {
    PlayerSetupPage()
}
