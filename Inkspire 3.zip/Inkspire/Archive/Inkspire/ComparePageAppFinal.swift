import SwiftUI

struct ComparePageAppFinal: View {
    let player1Name: String
    let player2Name: String
    let player1Drawing: UIImage
    let player2Drawing: UIImage
    
    @Binding var navigationPath: [String] // bind path from root
    
    var body: some View {
        ZStack {
            Image("BG")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()
            
            VStack(spacing: 40) {
                Text("FINAL DRAWINGS")
                    .font(.custom("Chalkduster", size: 35))
                    .foregroundColor(.black)
                    .multilineTextAlignment(.center)
                
                HStack(spacing: 20) {
                    VStack {
                        Text(player1Name)
                            .font(.title2.bold())
                            .foregroundColor(.black)
                        
                        Image(uiImage: player1Drawing)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 150, height: 300)
                            .border(Color.black, width: 2)
                    }
                    
                    VStack {
                        Text(player2Name)
                            .font(.title2.bold())
                            .foregroundColor(.black)
                        
                        Image(uiImage: player2Drawing)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 150, height: 300)
                            .border(Color.black, width: 2)
                    }
                }
                
                Spacer()
                
                Button(action: {
                    // ✅ Go back to root (ContentView)
                    navigationPath.removeAll()
                }) {
                    Text("Finish")
                        .frame(width: 180, height: 50)
                        .background(Color.black.opacity(0.3))
                        .foregroundColor(.white)
                        .cornerRadius(12)
                }
                .padding(.bottom, 50)
            }
            .padding(.top, 50)
        }
        .navigationBarBackButtonHidden(true)
    }
}

#Preview {
    ComparePageAppFinal(
        player1Name: "Tushar",
        player2Name: "Aryan",
        player1Drawing: UIImage(systemName: "scribble")!,
        player2Drawing: UIImage(systemName: "scribble")!,
        navigationPath: .constant(["ComparePage"])
    )
}

