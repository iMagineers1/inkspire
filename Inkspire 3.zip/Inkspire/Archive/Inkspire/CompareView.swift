//
//  CompareView.swift
//  Inkspire 4
//
//  Created by AFP Student 28 on 12/11/25.
//

import SwiftUI

struct ComparePage: View {
    let player1Name: String
    let player2Name: String
    
    @Environment(\.dismiss) var dismiss  // For back navigation
    
    var body: some View {
        NavigationStack {
            ZStack {
                // Same background as the app
                Image("BG")
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea()
                
                VStack(spacing: 60) {
                    
                    Text("Compare \nYour Drawings")
                        .font(.custom("Chalkduster", size: 35))
                        .multilineTextAlignment(.center)
                        .font(.largeTitle.bold())
                        .foregroundColor(.black)
                        .padding(.top, 130)
                    
                    HStack(spacing: 20) {
                        VStack(spacing: 10) {
                            Text(player1Name)
                                .font(.title2.bold())
                                .foregroundColor(.black)
                            
                            // Replace with actual drawing images if you have
                            Image("ink_18")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 140, height: 140)
                                .cornerRadius(12)
                                .shadow(radius: 5)
                        }
                        
                        VStack(spacing: 10) {
                            Text(player2Name)
                                .font(.title2.bold())
                                .foregroundColor(.black)
                            
                            Image("ink_18")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 140, height: 140)
                                .cornerRadius(12)
                                .shadow(radius: 5)
                        }
                    }
                    .padding(.top, 100)
                    
                    Spacer()
                    
                    // Back to Home Button
                    NavigationLink(destination: ContentView()) {
                        Text("Back to Home")
                            .font(.title3.bold())
                            .foregroundColor(.white)
                            .frame(width: 200, height: 40)
                            .background(Color.black.opacity(0.5))
                            .cornerRadius(12)
                            .padding(.bottom, 140)
                    }
                }
            }
        }
        .navigationBarBackButtonHidden(true)
    }
}

#Preview {
    ComparePage(player1Name: "Player One", player2Name: "Player Two")
}
