//
//  SwapYourDrawingPageApp.swift
//  Inkspire 4
//
//  Created by AFP Student 28 on 12/11/25.
//


import SwiftUI

struct SwapYourDrawingPageApp: View {
    let player1Name: String
    let player2Name: String
    let selectedTime: Int
    
    @State private var goToCanvas2 = false  // ✅ trigger navigation
    
    var body: some View {
        NavigationStack {
            ZStack {
                Image("BG")
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea()
                
                VStack(spacing: 50) {
                    
                    Spacer()
                    
                    Image("ink_18")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 400)
                    
                    Text("SWAP YOUR \nDRAWINGS")
                        .font(.custom("Chalkduster", size: 35))
                        .font(.largeTitle.bold())
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
                    
                    Spacer()
                    
                    // ✅ Continue Button
                    Button(action: {
                        goToCanvas2 = true
                    }) {
                        Text("Continue")
                            .frame(width: 180, height: 50)
                            .background(Color.black.opacity(0.3))
                            .foregroundColor(.white)
                            .cornerRadius(12)
                    }
                    .padding(.bottom, 100)
                    
                    // ✅ Hidden NavigationLink to CanvasDrawingPage2
                    NavigationLink(
                        destination: CanvasDrawingPage2(
                            player1: player1Name,
                            player2: player2Name,
                            selectedMinutes: selectedTime
                        ),
                        isActive: $goToCanvas2
                    ) {
                        EmptyView()
                    }
                    .hidden()
                }
            }
            
        }
    }
}

#Preview {
    SwapYourDrawingPageApp(
        player1Name: "Tushar",
        player2Name: "Aryan",
        selectedTime: 2
    )
}
