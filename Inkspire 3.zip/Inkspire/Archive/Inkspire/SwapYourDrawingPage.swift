    //
    //  Untitled.swift
    //  Inkspire 4
    //
    //  Created by AFP Student 28 on 12/11/25.
    //

    import SwiftUI

    struct SwapYourDrawingPage: View {
        let player1Name: String
        let player2Name: String
        let selectedTime: Int
        
        @State private var goToTimerPage2 = false  // ✅ State to trigger navigation
        
        var body: some View {
            NavigationStack {
                ZStack {
                    Image("BG")
                        .resizable()
                        .scaledToFill()
                        .ignoresSafeArea()
                    
                    VStack(spacing: 50) {
                        
                        Spacer()
                        
                        Image("ink_18")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 400)
                        
                        Text("SWAP YOUR \nDRAWINGS")
                            .font(.custom("Chalkduster", size: 35))
                            .font(.largeTitle.bold())
                            .foregroundColor(.black)
                            .multilineTextAlignment(.center)
                        
                        Spacer()
                        
                        // ✅ Programmatic Navigation
                        Button(action: {
                            goToTimerPage2 = true
                        }) {
                            Text("Continue")
                                .frame(width: 180, height: 50)
                                .background(Color.black.opacity(0.3))
                                .foregroundColor(.white)
                                .cornerRadius(12)
                        }
                        .padding(.bottom, 100)
                        
                        // Hidden NavigationLink triggered by state
                        NavigationLink(
                            destination: TimerPage2(
                                player1: player1Name,
                                player2: player2Name,
                                selectedMinutes: selectedTime
                            ),
                            isActive: $goToTimerPage2
                        ) {
                            EmptyView()
                        }
                        .hidden()
                    }
                }
                .navigationBarBackButtonHidden(true)
            }
        }
    }

    #Preview {
        SwapYourDrawingPage(
            player1Name: "Player One",
            player2Name: "Player Two",
            selectedTime: 1
        )
    }
