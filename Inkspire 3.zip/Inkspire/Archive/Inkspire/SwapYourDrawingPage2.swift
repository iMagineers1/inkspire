import SwiftUI

struct SwapYourDrawingPage2_2: View {
    var player1Name: String
    var player2Name: String
    var selectedTime: Int
    
    @State private var goToCompare = false  // ✅ Trigger Navigation
    
    var body: some View {
        NavigationStack {
            ZStack {
                Image("BG")
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea()
                
                VStack(spacing: 40) {
                    Spacer()
                    
                    Image("ink_18")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250)
                    
                    Text("SWAP YOUR \n DRAWINGS")
                        .font(.custom("Chalkduster", size: 35))
                        .font(.largeTitle.bold())
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
                    
                    Spacer()
                    
                    // Continue Button
                    Button(action: {
                        goToCompare = true  // ✅ Set state to navigate
                    }) {
                        Text("Continue")
                            .frame(width: 180, height: 50)
                            .background(Color.black.opacity(0.3))
                            .foregroundColor(.white)
                            .cornerRadius(12)
                    }
                    .padding(.bottom, 80)
                    
                    // ✅ Hidden NavigationLink triggered by state
                                        NavigationLink(
                                            destination: ComparePageAppFinal(
                                                player1Name: player1Name,
                                                player2Name: player2Name,
                                                player1Drawing: UIImage(systemName: "scribble")!,
                                                player2Drawing: UIImage(systemName: "scribble")!,
                                                navigationPath: .constant(["ComparePage"])
                                                
                                            ),
                        isActive: $goToCompare
                    ) {
                        EmptyView()
                    }
                    .hidden()
                }
            }
            .navigationBarBackButtonHidden(true)
        }
    }
}

#Preview {
    SwapYourDrawingPage2(player1Name: "Player One", player2Name: "Player Two", selectedTime: 1)
}

