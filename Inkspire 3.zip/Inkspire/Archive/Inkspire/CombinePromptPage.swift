import SwiftUI

struct CombinePromptPage: View {
    @State private var currentPrompt: String = ""
    
    // 10 example prompts
    let prompts = [
        "Giraffe and a spaceship!",
        "Cat and a pizza!",
        "Robot and a rainbow!",
        "Unicorn and a mountain!",
        "Dragon and a laptop!",
        "Cactus and a submarine!",
        "Octopus and a castle!",
        "Motorcycle and a cloud!",
        "Banana and a skyscraper!",
        "Drummer and a toaster!"
    ]
    
    var body: some View {
        NavigationStack {
            ZStack {
                Image("BG")
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea()
                
                VStack(spacing: 100) {
                    Spacer()
                    
                    // Top title
                    Text("COMBINE A...")
                        .font(.largeTitle.bold())
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
                        .padding(.top,)
                    
                    Spacer()
                    
                    // Center prompt
                    Text(currentPrompt)
                        .font(.title2.bold())
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal,0)
                    
                    // Small refresh button (icon only)
                    Button(action: {
                        currentPrompt = prompts.randomElement() ?? "Draw anything!"
                    }) {
                        Image(systemName: "arrow.clockwise.circle.fill")
                            .font(.title2) // small size
                            .foregroundColor(.black)
                    }
                    
                    Spacer()
                    
                    // Home button bottom-right
                    HStack {
                        Spacer()
                        NavigationLink(destination: ContentView()) {
                            Image(systemName: "house.fill")
                                .font(.title2)                  // smaller size
                                .padding(10)                     // reduced padding
                                .background(Color.black.opacity(0.3))
                                .foregroundColor(.white)
                                .cornerRadius(15)                // smaller corner radius
                        }
                        .padding()
                    }

                        .padding()
                    }
                }
            }
            .onAppear {
                // Set an initial random prompt
                currentPrompt = prompts.randomElement() ?? "Draw anything!"
            }
            .navigationBarBackButtonHidden(true)
        }
    }


#Preview {
    CombinePromptPage()
}

