import SwiftUI

struct CanvasDrawingPage: View {
    let player1: String
    let player2: String
    let selectedMinutes: Int
    
    @State private var lines: [Line] = []
    @State private var currentLine = Line(points: [])
    @State private var selectedColor: Color = .black
    @State private var lineWidth: CGFloat = 4.0
    @State private var timeRemaining: Int = 0
    @State private var timer: Timer? = nil
    @State private var goToSwapPage = false   // ✅ Navigation trigger
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationStack {
            ZStack {
                Image("BG")
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea()
                
                VStack {
                    // 🕒 Timer and Player Info
                    VStack(spacing: 8) {
                        Text("\(player1) & \(player2)")
                            .font(.title2.bold())
                            .foregroundColor(.black)
                        
                        Text("Time Remaining: \(formatTime(timeRemaining))")
                            .font(.headline)
                            .foregroundColor(.black.opacity(0.8))
                    }
                    .padding(.top, 40)
                    
                    Spacer()
                    
                    // 🎨 Drawing Canvas
                    GeometryReader { geometry in
                        ZStack {
                            Color.white
                                .cornerRadius(20)
                                .shadow(radius: 5)
                            
                            // Draw all lines
                            ForEach(lines) { line in
                                Path { path in
                                    guard let firstPoint = line.points.first else { return }
                                    path.move(to: firstPoint)
                                    for point in line.points.dropFirst() {
                                        path.addLine(to: point)
                                    }
                                }
                                .stroke(line.color, lineWidth: line.lineWidth)
                            }
                            
                            // Draw current line
                            Path { path in
                                guard let firstPoint = currentLine.points.first else { return }
                                path.move(to: firstPoint)
                                for point in currentLine.points.dropFirst() {
                                    path.addLine(to: point)
                                }
                            }
                            .stroke(currentLine.color, lineWidth: currentLine.lineWidth)
                        }
                        .gesture(
                            DragGesture(minimumDistance: 0)
                                .onChanged { value in
                                    let newPoint = value.location
                                    currentLine.points.append(newPoint)
                                    currentLine.color = selectedColor
                                    currentLine.lineWidth = lineWidth
                                }
                                .onEnded { _ in
                                    lines.append(currentLine)
                                    currentLine = Line(points: [])
                                }
                        )
                    }
                    .padding(.horizontal)
                    .frame(height: 400)
                    
                    Spacer()
                    
                    // 🎚 Controls
                    VStack(spacing: 12) {
                        // 🎨 Color Picker
                        HStack(spacing: 16) {
                            ForEach([Color.black, .red, .blue, .green, .orange, .purple, .gray], id: \.self) { color in
                                Circle()
                                    .fill(color)
                                    .frame(width: 30, height: 30)
                                    .overlay(
                                        Circle()
                                            .stroke(Color.white, lineWidth: selectedColor == color ? 3 : 0)
                                    )
                                    .onTapGesture {
                                        selectedColor = color
                                    }
                            }
                        }
                        
                        // ✏️ Brush Size
                        VStack(spacing: 6) {
                            Text("Brush Size: \(Int(lineWidth))")
                                .foregroundColor(.black)
                            Slider(value: $lineWidth, in: 1...10, step: 1)
                                .tint(.black)
                                .padding(.horizontal, 40)
                        }
                        
                        // ↩️ Undo Button
                        Button(action: {
                            if !lines.isEmpty {
                                lines.removeLast()
                            }
                        }) {
                            Label("Undo", systemImage: "arrow.uturn.left")
                                .padding()
                                .frame(width: 130)
                                .background(Color.black.opacity(0.8))
                                .foregroundColor(.white)
                                .cornerRadius(25)
                        }
                        .padding(.top, 10)
                        
                        // ✅ DONE BUTTON (Navigate to SwapYourDrawingPageApp)
                        Button(action: {
                            goToSwapPage = true
                        }) {
                            Text("Done")
                                .frame(width: 180, height: 45)
                                .background(Color.gray.opacity(0.5))
                                .foregroundColor(.black)
                                .cornerRadius(12)
                        }
                        .padding(.top, 10)
                        
                        // Hidden NavigationLink triggered by state
                        NavigationLink(
                            destination: SwapYourDrawingPageApp(
                                player1Name: player1,
                                player2Name: player2,
                                selectedTime: selectedMinutes
                            ),
                            isActive: $goToSwapPage
                        ) {
                            EmptyView()
                        }
                        .hidden()
                    }
                    .padding(.bottom, 40)
                }
            }
            .onAppear {
                startTimer()
            }
        }
    }
    
    // MARK: - Timer Logic
    func startTimer() {
        timeRemaining = selectedMinutes * 60
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            if timeRemaining > 0 {
                timeRemaining -= 1
            } else {
                timer?.invalidate()
                // Optional: Auto navigate when time finishes
                goToSwapPage = true
            }
        }
    }
    
    func formatTime(_ seconds: Int) -> String {
        let min = seconds / 60
        let sec = seconds % 60
        return String(format: "%02d:%02d", min, sec)
    }
}

// MARK: - Line Model
struct Line: Identifiable {
    let id = UUID()
    var points: [CGPoint]
    var color: Color = .black
    var lineWidth: CGFloat = 4.0
}

#Preview {
    CanvasDrawingPage(player1: "Tushar", player2: "Aryan", selectedMinutes: 2)
}
