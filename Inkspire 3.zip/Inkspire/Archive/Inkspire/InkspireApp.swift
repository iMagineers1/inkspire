//
//  InkspireApp.swift
//  Inkspire
//
//  Created by AFP Student 51 on 11/11/25.
//

import SwiftUI

@main
struct InkspireApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
