import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack {
            VStack(spacing: 32) {
                Image("Logo")
                    .resizable()
                    .scaledToFit()
                    .frame(height: 140)
                    .padding(.top, 32)
                
                
                // 📝 Reminder Text above the INKLINK button
                               Text("Take your pen and paper!")
                    .font(.title2.bold())
                                   .foregroundColor(.black)
                                   .multilineTextAlignment(.center)
                                   .padding(.horizontal, 20)
                                   .padding(.top, 10)
                
                VStack(spacing: 28) {
                    
                    // ✅ INKLINK button navigates to PlayerSetupPage
                    NavigationLink(destination: IntroPage()) {
                        GameButton(title: "INKLINK", subtitle: "Draw, swap and laugh!") {
                            Image("squids")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 160, height: 160)
                        }
                    }
                    
                    // ✅ Daily Challenge button
                    NavigationLink(destination: DailyChallengePage()) {
                        GameButton(title: "DAILY CHALLENGE", subtitle: "Mix the weird, sketch the wild!") {
                            Image("squid")
                                .resizable()
                                .scaledToFit()
                            
                                .frame(width: 150, height: 150)
                                .font(.system(size: 15, weight: .bold))
                        }
                    }
                }

                Spacer()
            }
            .padding(.horizontal, 20)
            .background(
                Image("background")
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea()
            )
        }
        .navigationBarBackButtonHidden(true)
    }
}

#Preview {
    ContentView()
}

