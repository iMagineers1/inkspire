//
//  GameButton.swift
//  Inkspire
//
//  Created by AFP Student 28 on 11/11/25.
//


//
//  GameButton.swift
//  Inkspire
//
//  Created by AFP Student 51 on 11/11/25.
//

import SwiftUI

struct GameButton<Content: View>: View {
    let title: String
    let subtitle: String
    let image: Content
    
    init(title: String, subtitle: String, @ViewBuilder image: () -> Content) {
        self.title = title
        self.subtitle = subtitle
        self.image = image()
    }
    
    var body: some View {
        HStack(spacing: 20) {
            image
                .cornerRadius(16)
                .scaledToFit()
                .frame(width: 130, height: 130)
            
            VStack(alignment: .leading, spacing: 8) {
                Text(title)
                    .font(.custom("Chalkduster", size: 18))
                    .fontWeight(.bold)
                    .foregroundColor(.primary)
                    
                Text(subtitle)
                    .font(.body)
                    .foregroundStyle(.black.opacity(0.8))
            }
            Spacer()
        }
        .padding(20)
        .glassEffect(in: .rect(cornerRadius: 16.0)) // Keep your glass effect modifier
        .cornerRadius(24)
        .frame(maxWidth: .infinity, minHeight: 200, maxHeight: 200)
        .shadow(color: .black.opacity(0.15), radius: 6, x: 0, y: 3)
    }
}

struct GameButton_Previews: PreviewProvider {
    static var previews: some View {
        GameButton(title: "Demo", subtitle: "This is a test") {
            Image(systemName: "star.fill")
                .resizable()
                .scaledToFit()
                .font(.system(size: 20, weight: .bold))
        }
        .previewLayout(.sizeThatFits)
        .padding()
    }
}
