import SwiftUI

struct SwapYourDrawingPage2_2: View {
    var player1Name: String
    var player2Name: String
    var selectedTime: Int
    
    @State private var goToCompare = false  // ✅ Trigger Navigation
    
    var body: some View {
        NavigationStack {
            ZStack {
                Image("BG")
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea()
                
                VStack(spacing: 40) {
                    Spacer()
                    
                    Image("ink_18")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250)
                    
                    Text("SWAP YOUR \nDRAWINGS")
                        .font(.custom("Chalkduster", size: 35))
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
                    
                    Spacer()
                    
                    // ✅ Continue Button triggers navigation
                    Button(action: {
                        goToCompare = true
                    }) {
                        Text("Continue")
                            .frame(width: 180, height: 50)
                            .background(Color.black.opacity(0.3))
                            .foregroundColor(.white)
                            .cornerRadius(12)
                    }
                    .padding(.bottom, 80)
                    
                    // ✅ Hidden NavigationLink that activates when goToCompare = true
                    NavigationLink(
                        destination: ComparePage(
                            player1Name: player1Name,
                            player2Name: player2Name
                        ),
                        isActive: $goToCompare
                    ) {
                        EmptyView()
                    }
                    .hidden()
                }
            }
            .navigationBarBackButtonHidden(true)
        }
    }
}

#Preview {
    SwapYourDrawingPage2_2(
        player1Name: "Tushar",
        player2Name: "Aryan",
        selectedTime: 2
    )
}

