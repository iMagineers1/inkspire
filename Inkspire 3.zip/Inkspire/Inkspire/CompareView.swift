import SwiftUI

struct ComparePage: View {
    let player1Name: String
    let player2Name: String
    
    var body: some View {
        ZStack {
            Image("BG")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()
            
            VStack(spacing: 10) {
                Spacer()
                
                // 🖼️ Center Image on top
                Image("ink_18")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 320, height: 320)
                    .cornerRadius(12)
                    .shadow(radius: 5)
                
                // 📝 Centered Title Text
                Text("Compare\nYour Drawings")
                    .font(.custom("Chalkduster", size: 35))
                    .multilineTextAlignment(.center)
                    .foregroundColor(.black)
                    .padding(.horizontal, 20)
                
                Spacer()
                
                // ✅ Back to Home Button
                NavigationLink(destination: ContentView()) {
                    Text("Back to Home")
                        .font(.title3.bold())
                        .foregroundColor(.white)
                        .frame(width: 200, height: 45)
                        .background(Color.black.opacity(0.5))
                        .cornerRadius(12)
                        .padding(.bottom, 120)
                }
            }
        }
        .navigationBarBackButtonHidden(true)
    }
}

#Preview {
    NavigationStack {
        ComparePage(player1Name: "Player One", player2Name: "Player Two")
    }
}

